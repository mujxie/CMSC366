#!/usr/bin/env python3
"""Create a small employer-facing SQL/CSV demonstration, not research evidence."""
import csv, sqlite3, argparse, html
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--out',type=Path,default=ROOT/'outputs/portfolio_demo');a=p.parse_args()
    a.out.mkdir(parents=True,exist_ok=False)
    c=sqlite3.connect(a.out/'sales.sqlite');c.execute('PRAGMA foreign_keys=ON')
    c.executescript((ROOT/'portfolio/schema.sql').read_text(encoding='utf-8'))
    for table in ['products','customers','sales','returns']:
        with (ROOT/'portfolio/data'/(table+'.csv')).open(encoding='utf-8',newline='') as f:
            reader=csv.DictReader(f);cols=reader.fieldnames;rows=list(reader)
            sql='INSERT INTO '+table+' ('+','.join(cols)+') VALUES ('+','.join('?' for _ in cols)+')'
            c.executemany(sql,[[r[k] for k in cols] for r in rows])
    c.commit()
    parts=['<!doctype html><html lang="en"><meta charset="utf-8"><title>Sales reporting demo</title><style>body{font:16px system-ui;max-width:900px;margin:2rem auto}table{border-collapse:collapse}th,td{border:1px solid #999;padding:.5rem}</style><h1>Historical sales reporting</h1><p>Synthetic employer demonstration. All monetary values are integer cents.</p>']
    for q in sorted((ROOT/'portfolio/queries').glob('*.sql')):
        cur=c.execute(q.read_text(encoding='utf-8'));headers=[d[0] for d in cur.description];rows=cur.fetchall()
        with (a.out/(q.stem+'.csv')).open('w',newline='',encoding='utf-8') as f:
            w=csv.writer(f);w.writerow(headers);w.writerows(rows)
        parts+=['<h2>'+html.escape(q.stem)+'</h2>','<table><tr>'+''.join('<th>'+html.escape(x)+'</th>' for x in headers)+'</tr>']
        for row in rows:parts.append('<tr>'+''.join('<td>'+html.escape(str(x))+'</td>' for x in row)+'</tr>')
        parts.append('</table>')
    # Known small totals, independently documented in portfolio/EXPECTED.txt.
    assert c.execute('SELECT SUM(quantity*unit_price_cents) FROM sales').fetchone()[0]==32500
    assert c.execute('SELECT SUM(refund_cents) FROM returns').fetchone()[0]==7500
    parts.append('<p>Checked totals: gross sales 32,500 cents; refunds 7,500 cents; net 25,000 cents. Two refunds apply to one sale: join aggregation must not duplicate its gross amount.</p></html>')
    (a.out/'dashboard.html').write_text('\n'.join(parts),encoding='utf-8');c.close();print('Created',a.out/'dashboard.html')
if __name__=='__main__':main()
