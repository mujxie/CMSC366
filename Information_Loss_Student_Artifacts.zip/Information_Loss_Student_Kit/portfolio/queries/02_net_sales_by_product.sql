-- Aggregate the many returns to one row per sale BEFORE joining to sales.
WITH refunds AS (
 SELECT sale_id, SUM(refund_cents) AS refund_cents FROM returns GROUP BY sale_id
)
SELECT p.product_name, SUM(s.quantity*s.unit_price_cents) AS gross_cents,
       SUM(COALESCE(r.refund_cents,0)) AS refunded_cents,
       SUM(s.quantity*s.unit_price_cents-COALESCE(r.refund_cents,0)) AS net_cents
FROM sales s JOIN products p ON s.product_id=p.product_id
LEFT JOIN refunds r ON r.sale_id=s.sale_id
GROUP BY p.product_id,p.product_name ORDER BY p.product_id;
