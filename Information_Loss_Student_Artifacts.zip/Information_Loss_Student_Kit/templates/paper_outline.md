# Research paper outline

Working title: On Detecting Information Loss in AI-Generated Database Designs

Do not write results in advance. A pilot with valid negative or zero effects can still be informative.

## Problem and Motivation
State a concrete historical-information requirement. Explain why executable SQL is not sufficient evidence of preserving that information. Distinguish design artifacts from pure DDL.

## Background and Related Work
Compare Text2Schema, SchemaAnalyst, and the closest semantic/temporal schema-testing work found during T06. Explain the bounded contribution; do not claim the first schema test, first AI repair method, or universal schema correctness.

## Approach and Uniqueness
Describe the six authored briefs, explicit event contracts, two model configurations, independent generations, paired repair branches, and frozen public/held-out split. Explain the state-collision argument with its event-mapping assumptions. State human-adjudication rules and protections against query-only misclassification.

## Results and Contributions
Report the generation flow and actual denominators, RQ1 adjudicated failures, RQ2 mechanism examples, and RQ3 within-parent held-out score differences. Report regressions, unresolved cases, invalid outputs, and budget/interface limitations. Never substitute teaching-control performance for empirical model results.

## Limitations and reproducibility
Small purposive brief set; repeated generations share a brief; one dialect; artifact includes update behavior; extra feedback also changes input length; fresh rebuilds are not migrations; human adjudication; model versions and dates. Provide scripts, anonymized/synthetic inputs, prompts, permitted raw outputs, and provenance records.

## Student contribution and AI assistance
Accurately state who authored requirements, tests, adapters, repairs, analysis, and prose. Follow the target venue's current policy.

Check the actual cycle's format, dates, eligibility, authorship, and AI policy before submission. Do not reuse old deadlines.
