CREATE TABLE subscribers (subscriber_id INTEGER PRIMARY KEY);
CREATE TABLE membership_periods (period_id INTEGER NOT NULL, subscriber_id INTEGER NOT NULL REFERENCES subscribers(subscriber_id), start_day TEXT NOT NULL, end_day TEXT, PRIMARY KEY (subscriber_id));
