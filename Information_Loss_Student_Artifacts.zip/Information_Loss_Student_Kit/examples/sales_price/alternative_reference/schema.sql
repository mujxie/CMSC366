CREATE TABLE products(product_id INTEGER PRIMARY KEY);
CREATE TABLE price_versions(
 product_id INTEGER NOT NULL REFERENCES products(product_id), version_no INTEGER NOT NULL,
 price_cents INTEGER NOT NULL CHECK(price_cents >= 0), PRIMARY KEY(product_id,version_no));
CREATE TABLE sale_items(
 sale_id INTEGER PRIMARY KEY, product_id INTEGER NOT NULL, version_no INTEGER NOT NULL,
 quantity INTEGER NOT NULL CHECK(quantity > 0),
 FOREIGN KEY(product_id,version_no) REFERENCES price_versions(product_id,version_no));
