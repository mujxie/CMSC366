-- Current prices are displayed for comparison, NEVER substituted into historical sales.
SELECT s.sale_id, p.product_name, s.quantity, s.unit_price_cents,
       s.quantity*s.unit_price_cents AS original_total_cents,
       p.current_price_cents
FROM sales s JOIN products p ON p.product_id=s.product_id
ORDER BY s.sale_id;
