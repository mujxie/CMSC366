-- DELIBERATELY WRONG query for an interview exercise: sale 101 appears twice.
SELECT SUM(s.quantity*s.unit_price_cents)-SUM(COALESCE(r.refund_cents,0)) AS wrong_net_cents
FROM sales s LEFT JOIN returns r ON r.sale_id=s.sale_id;
