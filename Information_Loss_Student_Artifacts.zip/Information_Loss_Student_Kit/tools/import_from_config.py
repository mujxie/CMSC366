#!/usr/bin/env python3
"""Use a JSON config instead of typing a long response-import command."""
import json,sys,subprocess
from pathlib import Path
if len(sys.argv)!=2:
    raise SystemExit('Usage: python tools/import_from_config.py templates/my_import.json')
c=json.loads(Path(sys.argv[1]).read_text(encoding='utf-8'))
cmd=[sys.executable,str(Path(__file__).with_name('import_response.py'))]
for key,value in c.items():
    cmd.extend(['--'+key.replace('_','-'),str(value)])
raise SystemExit(subprocess.run(cmd,check=False).returncode)
