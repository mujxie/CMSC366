CREATE TABLE products (product_id INTEGER PRIMARY KEY, current_price_cents INTEGER NOT NULL CHECK (current_price_cents >= 0));
CREATE TABLE sale_items (sale_id INTEGER PRIMARY KEY, product_id INTEGER NOT NULL REFERENCES products(product_id), quantity INTEGER NOT NULL CHECK (quantity > 0), unit_price_cents INTEGER NOT NULL);
