#!/usr/bin/env python3
"""Reproducible, offline database-design evaluation. Python 3.10+, standard library.

This runs SQL designs; it does NOT query a model or infer a schema defect from a
wrong answer. Collisions require human review of the event mapping and all state.
"""
from __future__ import annotations
import argparse
import csv
import hashlib
import html
import json
import platform
import shutil
import sqlite3
import sys
import tempfile
import time
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
VERSION = '1.0.0'
MAX_ROWS = 2000
MAX_SQL_BYTES = 250_000


def load(path: Path) -> Any:
    return json.loads(path.read_text(encoding='utf-8'))


def save(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False, default=str)+'\n', encoding='utf-8')


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def canonical(data: Any) -> str:
    return json.dumps(data, sort_keys=True, ensure_ascii=False, separators=(',', ':'), default=str)


def quoted(name: str) -> str:
    return '"' + name.replace('"', '""') + '"'


def safe_value(v: Any) -> Any:
    if isinstance(v, bytes):
        return {'sqlite_blob_hex': v.hex()}
    return v


def rows_to_list(rows: list[tuple]) -> list[list]:
    return [[safe_value(v) for v in row] for row in rows]


def bag(rows: list) -> list[str]:
    """Compare multisets, not row order; preserve duplicate rows and NULLs."""
    return sorted(canonical(row) for row in rows)


def sql_guard(action, arg1, arg2, database, source):
    denied = {sqlite3.SQLITE_ATTACH, sqlite3.SQLITE_DETACH,
              sqlite3.SQLITE_CREATE_VTABLE, sqlite3.SQLITE_DROP_VTABLE}
    if action in denied:
        return sqlite3.SQLITE_DENY
    if action == sqlite3.SQLITE_FUNCTION:
        if (arg2 or arg1 or '').lower() in {'load_extension', 'readfile', 'writefile', 'random', 'randomblob'}:
            return sqlite3.SQLITE_DENY
    if action == sqlite3.SQLITE_PRAGMA:
        name = (arg1 or '').lower()
        if name == 'foreign_keys' and (arg2 is None or str(arg2).lower() in {'on','1'}):
            return sqlite3.SQLITE_OK
        return sqlite3.SQLITE_DENY
    return sqlite3.SQLITE_OK


def connect(path: Path, read_only: bool = False) -> sqlite3.Connection:
    c = sqlite3.connect(path)
    c.execute('PRAGMA foreign_keys = ON')
    if c.execute('PRAGMA foreign_keys').fetchone()[0] != 1:
        raise RuntimeError('Foreign-key enforcement could not be enabled.')
    if read_only:
        c.execute('PRAGMA query_only = ON')
    try:
        c.enable_load_extension(False)
    except AttributeError:
        pass
    c.set_authorizer(sql_guard)
    return c


def budget(c: sqlite3.Connection, seconds: float = 2.0) -> None:
    deadline = time.monotonic()+seconds
    calls = [0]
    def stop():
        calls[0] += 1
        return int(time.monotonic() > deadline or calls[0] > 20000)
    c.set_progress_handler(stop, 1000)


def fetch(c: sqlite3.Connection, query: str) -> list[list]:
    budget(c)
    cur = c.execute(query)
    if cur.description is None:
        raise ValueError('A report query must return rows.')
    rows = cur.fetchmany(MAX_ROWS+1)
    if len(rows) > MAX_ROWS:
        raise ValueError(f'Report exceeds {MAX_ROWS} rows; check query or revise the registered limit.')
    return rows_to_list(rows)


def snapshot(c: sqlite3.Connection) -> dict:
    """All persistent user-table values, declared columns, and sqlite_sequence.

    Physical page bytes and undeclared rowid are not business information. Extra
    declared keys, audit tables, and stored JSON/BLOBs ARE included. Views derive
    from tables and are included in the schema definition but not as new state.
    """
    budget(c)
    tables = c.execute("SELECT name, sql FROM sqlite_master WHERE type='table' "
                       "AND (name NOT LIKE 'sqlite_%' OR name='sqlite_sequence') ORDER BY name").fetchall()
    ans = {}
    for name, ddl in tables:
        cur = c.execute('SELECT * FROM '+quoted(name))
        data = cur.fetchmany(MAX_ROWS+1)
        if len(data) > MAX_ROWS:
            raise ValueError('Snapshot too large for this small benchmark.')
        ans[name] = {'columns':[x[0] for x in cur.description],
                     'rows': sorted(rows_to_list(data), key=canonical)}
    return ans


def case_files(cid: str, split: str) -> tuple[dict, list[dict], list[Path]]:
    base = ROOT/'cases'/cid
    if not base.is_dir():
        raise ValueError('Unknown brief: '+cid)
    contract = load(base/'contract.json')
    paths = []
    histories = []
    if split in {'public', 'all'}:
        paths.append(base/'public.json')
    if split in {'holdout', 'all'}:
        p = ROOT/'supervisor_only/holdouts'/(cid+'.json')
        if not p.exists():
            raise ValueError('Held-out cases are supervisor-only and not present in this copy.')
        paths.append(p)
    for p in paths:
        histories.extend(load(p)['histories'])
    return contract, histories, paths


def run_history(schema: str, adapter: dict, h: dict) -> dict:
    r = {'history_id':h['history_id'], 'split':h['split'], 'pair_id':h.get('pair_id'),
         'expected':h['expected'], 'actual':None, 'passed':False,
         'ddl_ok':False, 'events_ok':False, 'query_ok':False,
         'status':'not_run', 'events_executed':0, 'state':None, 'trace':[]}
    c = None
    with tempfile.TemporaryDirectory(prefix='dbdesign_') as d:
        p = Path(d)/'candidate.sqlite'
        try:
            c = connect(p); budget(c)
            c.executescript(schema); c.commit()
            r['ddl_ok'] = True
            for index, event in enumerate(h['events']):
                statements = adapter['operations'][event['op']]
                if not isinstance(statements, list) or not statements:
                    raise ValueError('Every operation must map to a nonempty SQL list.')
                before = c.total_changes
                for statement in statements:
                    if not isinstance(statement, str):
                        raise ValueError('Operation entries must be SQL strings, not Python.')
                    budget(c)
                    c.execute(statement, event['params'])
                c.commit()
                r['events_executed'] += 1
                r['trace'].append({'index':index, 'op':event['op'], 'changes':c.total_changes-before})
            r['events_ok'] = True
            c.close(); c = None
            # Reports and snapshots must work after the connection is reopened.
            c = connect(p, read_only=True)
            r['state'] = snapshot(c)
            r['state_sha256'] = hashlib.sha256(canonical(r['state']).encode()).hexdigest()
            actual = fetch(c, adapter['query'])
            r['actual'] = actual; r['query_ok'] = True
            r['passed'] = bag(actual) == bag(h['expected'])
            r['status'] = 'pass' if r['passed'] else 'answer_mismatch'
        except (sqlite3.Error, ValueError, KeyError, TypeError) as e:
            r['status'] = ('ddl_error' if not r['ddl_ok'] else
                           'event_error' if not r['events_ok'] else 'report_error')
            r['error'] = type(e).__name__+': '+str(e)
        finally:
            if c is not None:
                c.close()
    return r


def collision_checks(records: list[dict]) -> list[dict]:
    groups = {}
    for r in records:
        if r.get('pair_id'):
            groups.setdefault(r['pair_id'], []).append(r)
    out=[]
    for pair, members in sorted(groups.items()):
        if len(members) != 2:
            raise ValueError('Each pair must contain exactly two histories: '+pair)
        a,b = members
        available = a['state'] is not None and b['state'] is not None
        same = available and a['state'] == b['state']
        different = bag(a['expected']) != bag(b['expected'])
        out.append({'pair_id':pair, 'histories':[a['history_id'],b['history_id']],
                    'states_available':available, 'same_declared_state':same,
                    'different_required_answers':different,
                    'collision_candidate':bool(same and different),
                    'human_adjudication_required':True,
                    'interpretation':'Witness concerns this design AND its event mapping. It is not proof against every possible use of the schema.'})
    return out


def evaluate(candidate: Path, cid: str, split: str, output: Path) -> dict:
    if (output/'result.json').exists():
        raise ValueError('Refusing to overwrite a result. Choose a new --out directory.')
    contract, histories, fixtures = case_files(cid, split)
    needed = ['schema.sql','adapter.json','manifest.json']
    for name in needed:
        if not (candidate/name).exists():
            raise ValueError('Missing candidate file: '+name)
    schema = (candidate/'schema.sql').read_text(encoding='utf-8')
    if len(schema.encode()) > MAX_SQL_BYTES or not schema.strip():
        raise ValueError('Schema is empty or exceeds size limit.')
    adapter = load(candidate/'adapter.json'); meta=load(candidate/'manifest.json')
    if meta.get('brief_id') != cid:
        raise ValueError('manifest.brief_id does not match --case.')
    expected_ops = set(contract['operations'])
    if set(adapter.get('operations',{})) != expected_ops:
        raise ValueError('Operation names must match contract exactly: '+str(sorted(expected_ops)))
    if not isinstance(adapter.get('query'),str) or not adapter['query'].strip():
        raise ValueError('A report query is required.')
    records = [run_history(schema,adapter,h) for h in histories]
    collisions=collision_checks(records)
    result = {'tool_version':VERSION, 'generated_utc':datetime.now(timezone.utc).isoformat(),
              'python':platform.python_version(), 'sqlite':sqlite3.sqlite_version,
              'candidate':str(candidate.resolve()), 'manifest':meta, 'brief_id':cid,'split':split,
              'provenance':{'candidate_hashes':{n:sha(candidate/n) for n in needed},
                            'fixture_hashes':{str(p.relative_to(ROOT)):sha(p) for p in fixtures},
                            'runner_hash':sha(Path(__file__))},
              'counts':{'histories':len(records),'passed':sum(r['passed'] for r in records),
                        'ddl_ok':sum(r['ddl_ok'] for r in records),
                        'events_ok':sum(r['events_ok'] for r in records),
                        'query_ok':sum(r['query_ok'] for r in records),
                        'collision_candidates':sum(x['collision_candidate'] for x in collisions)},
              'histories':records,'paired_histories':collisions,
              'research_warning':'Test failure is not automatically a schema defect. Teaching-fixture results are not empirical AI results.'}
    output.mkdir(parents=True,exist_ok=True)
    save(output/'result.json',result)
    with (output/'histories.csv').open('w',newline='',encoding='utf-8') as f:
        fields=['history_id','split','pair_id','status','passed','ddl_ok','events_ok','query_ok','events_executed','expected','actual','error']
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader()
        for r in records:
            w.writerow({k:canonical(r[k]) if k in {'actual','expected'} else r.get(k,'') for k in fields})
    render_html(result,output/'report.html')
    return result


def render_html(r: dict, path: Path) -> None:
    esc=lambda s: html.escape(str(s))
    parts=['<!doctype html><html lang="en"><meta charset="utf-8"><title>Database design test report</title>',
           '<style>body{font:16px system-ui;margin:2rem auto;max-width:1100px;padding:0 1rem}table{border-collapse:collapse;width:100%}td,th{border:1px solid #bbb;padding:.5rem;text-align:left}pre{white-space:pre-wrap;overflow-wrap:anywhere}h2{margin-top:2rem}</style>',
           '<h1>Database design test report</h1>',
           '<p><strong>Origin: '+esc(r['manifest'].get('origin','unknown'))+'</strong>. '+esc(r['research_warning'])+'</p>',
           '<p>Artifact: '+esc(r['manifest'].get('artifact_id'))+' | Brief: '+esc(r['brief_id'])+' | Split: '+esc(r['split'])+'</p>',
           '<pre>'+esc(json.dumps(r['counts'],indent=2))+'</pre>',
           '<table><tr><th>History</th><th>Status</th><th>Expected rows</th><th>Observed rows / error</th></tr>']
    for h in r['histories']:
        parts.append('<tr><td>'+esc(h['history_id'])+'</td><td>'+esc(h['status'])+'</td><td>'+esc(h['expected'])+'</td><td>'+esc(h.get('error',h['actual']))+'</td></tr>')
    parts.append('</table><h2>Paired-history collision checks</h2>')
    parts.append('<p>A flagged collision needs a human review of the documented event mapping, all persisted tables, and any alternative encoding. A passing test is not a proof of general correctness.</p>')
    for p in r['paired_histories']:
        parts.append('<pre>'+esc(json.dumps(p,indent=2))+'</pre>')
    parts.append('<h2>Event traces and stored state</h2>')
    for h in r['histories']:
        parts.append('<details><summary>'+esc(h['history_id'])+'</summary><pre>'+esc(json.dumps({'trace':h['trace'],'state':h['state']},indent=2))+'</pre></details>')
    parts.append('</html>');path.write_text('\n'.join(parts),encoding='utf-8')


def demo(out: Path, split: str) -> dict:
    summary=[]
    for case in load(ROOT/'cases/index.json'):
        cid=case['brief_id']
        for variant in ['reference','seeded_bad']:
            r=evaluate(ROOT/'examples'/cid/variant,cid,split,out/cid/variant)
            summary.append({'brief_id':cid,'variant':variant,**r['counts']})
    total={'status':'demonstration_only','entries':summary,
           'histories_executed':sum(x['histories'] for x in summary),
           'note':'Authored positive and deliberately flawed controls. No AI outputs were collected.'}
    save(out/'demo_summary.json',total)
    print(json.dumps(total,indent=2));return total


def init_candidate(cid: str, aid: str, out: Path) -> None:
    contract,_,_=case_files(cid,'public')
    out.mkdir(parents=True,exist_ok=False)
    (out/'schema.sql').write_text('-- Replace with the ORIGINAL collected DDL. Do not copy a fixture.\n',encoding='utf-8')
    save(out/'adapter.json',{'operations':{k:['-- Replace with parameterized SQL; no schema changes here.'] for k in contract['operations']},'query':'-- Replace with the required SELECT query.'})
    save(out/'manifest.json',{'artifact_id':aid,'brief_id':cid,'origin':'llm_collected','stage':'baseline','parent_id':'','model':'FILL_EXACT_MODEL','provider':'FILL_PROVIDER','replicate':1,'generated_utc':'FILL_TIMESTAMP','settings':'FILL_KNOWN_SETTINGS_OR_UNAVAILABLE','student_owner':'FILL_NAME','raw_output_file':'raw_response.txt','adapter_reviewed':False,'adapter_reviewer':'','notes':'Keep raw output immutable. Classify adapter and query defects separately.'})
    (out/'raw_response.txt').write_text('PASTE THE ENTIRE ORIGINAL RESPONSE HERE.\n',encoding='utf-8')
    (out/'design_notes.md').write_text('# Event-mapping review\n\nExplain each table and every adapter operation. No hidden storage or hand repair.\n',encoding='utf-8')


def make_plan(out: Path, briefs: list[str], models: list[str], reps: int) -> None:
    if out.exists():raise ValueError('Plan already exists.')
    fields=['artifact_id','parent_id','brief_id','model','replicate','stage','candidate_path','result_path','status']
    with out.open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader()
        for b in briefs:
            case_files(b,'public')
            for m in models:
                for n in range(1,reps+1):
                    parent=f'{b}_{m}_r{n:02d}'
                    for stage in ['baseline','self_review','example_review']:
                        aid=parent+'_'+stage
                        w.writerow(dict(artifact_id=aid,parent_id=parent,brief_id=b,model=m,replicate=n,stage=stage,candidate_path='candidates/'+aid,result_path='outputs/collected/'+aid,status='not_collected'))


def run_plan(plan: Path, output: Path, split: str) -> None:
    rows=list(csv.DictReader(plan.open(encoding='utf-8',newline='')))
    log=[]
    for row in rows:
        p=ROOT/row['candidate_path']
        if row.get('status') not in {'frozen','ready'}:
            log.append({'artifact_id':row['artifact_id'],'status':'skipped_not_frozen'});continue
        try:
            m=load(p/'manifest.json')
            if m.get('origin') != 'llm_collected':
                raise ValueError('Empirical plan may not include teaching fixtures.')
            if m.get('artifact_id') != row['artifact_id'] or m.get('stage') != row['stage']:
                raise ValueError('Manifest and registry disagree.')
            raw=p/m.get('raw_output_file','raw_response.txt')
            if not raw.exists() or 'PASTE THE ENTIRE ORIGINAL' in raw.read_text(encoding='utf-8'):
                raise ValueError('Original collected response is missing.')
            if not m.get('adapter_reviewed'):
                raise ValueError('Adapter must be reviewed before testing.')
            r=evaluate(p,row['brief_id'],split,output/row['artifact_id'])
            log.append({'artifact_id':row['artifact_id'],'status':'evaluated','counts':r['counts']})
        except (OSError,ValueError,KeyError,json.JSONDecodeError) as e:
            log.append({'artifact_id':row['artifact_id'],'status':'not_evaluated','reason':str(e)})
    save(output/'run_plan_log.json',log)
    print('Evaluated',sum(x['status']=='evaluated' for x in log),'artifacts; see run_plan_log.json for all skips/errors.')


def summarize(result_root: Path, out: Path) -> dict:
    items=[]
    for path in sorted(result_root.rglob('result.json')):
        r=load(path)
        if r['manifest'].get('origin') != 'llm_collected':continue
        items.append(r)
    if not items:
        answer={'status':'no_collected_model_results','message':'Teaching controls are excluded. No AI performance estimate is available.'}
        save(out/'analysis.json',answer);print(json.dumps(answer));return answer
    by_artifact={}
    for r in items:
        aid=r['manifest']['artifact_id']
        if aid in by_artifact:
            raise ValueError('Duplicate results for artifact '+aid+'; choose one frozen analysis folder.')
        by_artifact[aid]=r
    groups={};baseline=[]
    for r in items:
        m=r['manifest'];key=(m.get('parent_id') or m['artifact_id'],r['brief_id'],m['model'],m['replicate'])
        groups.setdefault(key,{})[m['stage']]=r
        if m['stage']=='baseline':baseline.append(r)
    comparisons=[]
    for key,g in groups.items():
        if not all(s in g for s in ['baseline','self_review','example_review']):continue
        scores={}
        for stage,r in g.items():
            hh=[h for h in r['histories'] if h['split']=='holdout']
            if len(hh)!=4:raise ValueError('Each analyzed artifact must include four held-out histories.')
            scores[stage]=sum(h['passed'] for h in hh)/len(hh)
        base_by={h['history_id']:h['passed'] for h in g['baseline']['histories'] if h['split']=='holdout'}
        reg={}
        for stage in ['self_review','example_review']:
            stage_by={h['history_id']:h['passed'] for h in g[stage]['histories'] if h['split']=='holdout'}
            reg[stage]=sum(passed and not stage_by.get(hid,False) for hid,passed in base_by.items())
        comparisons.append({'parent_id':key[0],'brief_id':key[1],'model':key[2],'replicate':key[3],**scores,'example_minus_self':scores['example_review']-scores['self_review'],'regressions':reg})
    baseline_flags=[]
    for r in baseline:
        baseline_flags.append({'artifact_id':r['manifest']['artifact_id'],'brief_id':r['brief_id'],
                               'ddl_executable':all(h['ddl_ok'] for h in r['histories']),
                               'any_answer_or_execution_failure':any(not h['passed'] for h in r['histories']),
                               'collision_candidate':any(p['collision_candidate'] for p in r['paired_histories'])})
    avg=lambda xs:sum(xs)/len(xs) if xs else None
    by_brief=[]
    for cid in sorted({x['brief_id'] for x in comparisons}):
        cc=[x for x in comparisons if x['brief_id']==cid]
        by_brief.append({'brief_id':cid,'complete_parent_blocks':len(cc),'mean_example_minus_self':avg([x['example_minus_self'] for x in cc])})
    answer={'status':'descriptive_only','baseline_artifacts':len(baseline),'complete_paired_parent_blocks':len(comparisons),
            'baseline_flags_for_human_adjudication':baseline_flags,'paired_comparisons':comparisons,'by_brief':by_brief,
            'mean_paired_difference':avg([x['example_minus_self'] for x in comparisons]),
            'warning':'No automatic confirmed schema-defect rate. Merge human adjudication. Histories are correlated; do not treat each query or history as an independent model sample. No p-values or general-population claims are computed.'}
    save(out/'analysis.json',answer)
    fields=['parent_id','brief_id','model','replicate','baseline','self_review','example_review','example_minus_self']
    with (out/'paired_scores.csv').open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader()
        for row in comparisons:w.writerow({k:row[k] for k in fields})
    print('Wrote descriptive paired analysis; human defect classification remains required.');return answer


def freeze(out: Path) -> None:
    paths=[]
    for base in ['cases','prompts','supervisor_only/holdouts','tools']:
        paths.extend(p for p in (ROOT/base).rglob('*') if p.is_file() and '__pycache__' not in str(p))
    save(out,{'created_utc':datetime.now(timezone.utc).isoformat(),'files':{str(p.relative_to(ROOT)):sha(p) for p in sorted(paths)},'note':'Save this manifest before model collection. Any changed requirement, prompt, adapter policy, or test requires a recorded protocol revision.'})


def main():
    p=argparse.ArgumentParser(description=__doc__)
    sp=p.add_subparsers(dest='command',required=True)
    sp.add_parser('doctor')
    d=sp.add_parser('demo');d.add_argument('--out',type=Path,default=ROOT/'outputs/demo');d.add_argument('--split',choices=['public','all'],default='all')
    e=sp.add_parser('evaluate');e.add_argument('--case',required=True);e.add_argument('--candidate',type=Path,required=True);e.add_argument('--split',choices=['public','holdout','all'],default='public');e.add_argument('--out',type=Path,required=True)
    i=sp.add_parser('init-candidate');i.add_argument('--case',required=True);i.add_argument('--id',required=True);i.add_argument('--out',type=Path,required=True)
    m=sp.add_parser('make-plan');m.add_argument('--out',type=Path,required=True);m.add_argument('--briefs',nargs='+',default=[x['brief_id'] for x in load(ROOT/'cases/index.json')]);m.add_argument('--models',nargs='+',default=['M1','M2']);m.add_argument('--replicates',type=int,default=3)
    rr=sp.add_parser('run-plan');rr.add_argument('--plan',type=Path,required=True);rr.add_argument('--out',type=Path,required=True);rr.add_argument('--split',choices=['public','all'],default='all')
    ss=sp.add_parser('summarize');ss.add_argument('--results',type=Path,required=True);ss.add_argument('--out',type=Path,required=True)
    ff=sp.add_parser('freeze');ff.add_argument('--out',type=Path,required=True)
    a=p.parse_args()
    try:
        if sys.version_info < (3,10):raise ValueError('Use Python 3.10 or newer.')
        if a.command=='doctor':
            if sqlite3.sqlite_version_info < (3,24,0):raise ValueError('SQLite 3.24+ required for the teaching UPSERT examples.')
            print(json.dumps({'tool_version':VERSION,'python':platform.python_version(),'sqlite':sqlite3.sqlite_version,'package_root':str(ROOT),'ready':True},indent=2))
        elif a.command=='demo':demo(a.out,a.split)
        elif a.command=='evaluate':
            r=evaluate(a.candidate,a.case,a.split,a.out);print(json.dumps(r['counts'],indent=2));print('Report:',a.out/'report.html')
        elif a.command=='init-candidate':init_candidate(a.case,a.id,a.out)
        elif a.command=='make-plan':make_plan(a.out,a.briefs,a.models,a.replicates)
        elif a.command=='run-plan':run_plan(a.plan,a.out,a.split)
        elif a.command=='summarize':summarize(a.results,a.out)
        elif a.command=='freeze':freeze(a.out)
    except (OSError,ValueError,KeyError,json.JSONDecodeError) as ex:
        p.exit(2,'ERROR: '+str(ex)+'\n')


if __name__=='__main__':
    main()
