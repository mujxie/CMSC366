import unittest, sys, tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))
import study
class StarterTests(unittest.TestCase):
    def check_variant(self,variant,passed,collisions):
        with tempfile.TemporaryDirectory() as d:
            r=study.evaluate(ROOT/'examples/sales_price'/variant,'sales_price','public',Path(d)/'result')
            self.assertEqual(r['counts']['histories'],4)
            self.assertEqual(r['counts']['passed'],passed)
            self.assertEqual(r['counts']['collision_candidates'],collisions)
    def test_snapshot_reference(self):self.check_variant('reference',4,0)
    def test_versioned_alternative(self):self.check_variant('alternative_reference',4,0)
    def test_deliberately_flawed_design(self):self.check_variant('seeded_bad',2,1)
if __name__=='__main__':unittest.main(verbosity=2)
