CREATE TABLE customers (customer_id INTEGER PRIMARY KEY, current_address TEXT NOT NULL);
CREATE TABLE orders (order_id INTEGER PRIMARY KEY, customer_id INTEGER NOT NULL REFERENCES customers(customer_id));
