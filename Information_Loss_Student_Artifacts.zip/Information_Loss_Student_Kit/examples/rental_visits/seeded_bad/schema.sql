CREATE TABLE assets (asset_id INTEGER PRIMARY KEY);
CREATE TABLE rentals (rental_id INTEGER NOT NULL, asset_id INTEGER NOT NULL REFERENCES assets(asset_id), checkout_day TEXT NOT NULL, return_day TEXT, PRIMARY KEY (asset_id));
