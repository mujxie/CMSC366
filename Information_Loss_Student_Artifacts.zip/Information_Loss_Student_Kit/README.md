# Database Design Research Kit

**Project:** On Detecting Information Loss in AI-Generated Database Designs  
**Audience:** an undergraduate who prefers database design; one supervisor; optional 2–3-person team.  
**Status:** runnable teaching/research infrastructure. **No empirical AI-model study has been completed.**

Start with `docs/Database_Design_Research_Guide.docx`. It contains task assignments,
research-question mappings, commands, expected outputs, and assessment gates.

## Requirements

Python 3.10 or newer with its built-in `sqlite3` module; SQLite 3.24 or newer.
No pip packages, API keys, database server, Docker, or cloud account are required.
For Windows use `py -3` where examples say `python`; on macOS/Linux use `python3`.
Run every command from the extracted package root. Do not run inside the ZIP.

```text
python tools/study.py doctor
python -m unittest discover -s tests -v
python tools/study.py demo --out outputs/my_first_demo
python tools/portfolio_demo.py --out outputs/my_portfolio
```

Double-click `run_demo.bat` on Windows or run `sh run_demo.sh` on macOS/Linux.
A repeated command must use a NEW output folder; the runner deliberately refuses
to overwrite evidence. Open the produced `report.html` files in a browser.

## First 30 minutes

1. Open `cases/sales_price/requirements.md` and calculate the original sale amount.
2. Read `examples/sales_price/seeded_bad/schema.sql` and `adapter.json`.
3. Run:

```text
python tools/study.py evaluate --case sales_price --candidate examples/sales_price/seeded_bad --split public --out outputs/sales_bad_public
python tools/study.py evaluate --case sales_price --candidate examples/sales_price/reference --split public --out outputs/sales_reference_public
```

4. Open both `report.html` files. Explain why two histories can end in identical
   stored records but require different original-sale totals.
5. Read `examples/sales_price/alternative_reference`: versioned prices also work.
   Do not grade a candidate by whether its tables resemble our reference.

## What is included

- Six explicit business requirements and event/report contracts.
- Four public and four supervisor-held-out histories per brief (48 total).
- Six reference and six deliberately flawed designs, plus one valid alternative.
- A parameterized-SQL runner: executes, closes/reopens, checks reports, snapshots
  all declared persisted table columns, and flags paired-history collisions.
- Prompt builder for generation, self-review, and example-based review.
- Raw-response importer, experiment-registry generator, paired descriptive analysis.
- Blank logs, adjudication forms, contribution tracking, and employer/demo templates.
- A CSV-to-SQL reporting demonstration with historical prices and multiple refunds.
- Source code, tests, and actual local software-verification outputs.

## Important distinctions

`examples/` and `outputs/demo_verified/` are **authored teaching controls**, not
outputs from a sampled model. Their failures cannot be used to estimate an AI
error rate. The actual experiment requires collecting and freezing raw outputs
in `candidates/`, followed by human review. `summarize` excludes fixture origins.

A wrong query does not prove missing data. A state collision supports an
information-loss claim for the **evaluated design plus its documented event
mapping** after human adjudication; it does not prove that every implementation
of a table structure must lose information. The runner is not a schema theorem
prover, production database, or strong sandbox for malicious SQL.

## Supervisor-only material

Do not give `supervisor_only/holdouts/` to a model or include it in prompts.
Freeze both repair branches before the supervisor runs held-out tests. Students
may inspect public test cases. The included `Database_Design_Student_Starter.zip` distribution
(when delivered alongside this kit) omits held-out answers and most reference
solutions. The supervisor receives the complete package.

## Study plan

Full study: 6 briefs × 2 model configurations × 3 initial generations = 36
baseline designs. Each initial design gets two independent repair branches,
yielding 108 scheduled artifacts and at most 864 history executions (108 × 8).
The unit for paired repair comparisons is the ORIGINAL design: 36 blocks, not
864 independent observations. Failed collection/format/DDL stages stay in the
flow diagram and registry. Do not silently replace unsuccessful generations.

```text
python tools/study.py make-plan --out templates/my_full_plan.csv
python tools/study.py freeze --out templates/my_protocol_freeze.json
python tools/prompts.py --case sales_price --stage baseline --out outputs/sales_generation_prompt.txt
```

The student sends saved prompts manually to two selected models. The package
makes NO network requests and chooses no current model or pricing plan.
Record exact model IDs, dates, settings, costs, and interface limitations.

## Safety and attribution

Use only synthetic data. Inspect collected SQL before execution. The runner blocks
ATTACH, extensions, virtual tables, several file functions, and query writes, and
uses small temporary databases plus query limits; this is not complete security
isolation. Treat unexpected code or shell commands as data, never execute them.

The initial kit was authored with OpenAI ChatGPT assistance. Preserve provenance
and disclose research-design/code assistance under the actual target venue's
policy. Students must explain, verify, and document their own contributions.
This project does not guarantee conference acceptance, employment, or novelty.
