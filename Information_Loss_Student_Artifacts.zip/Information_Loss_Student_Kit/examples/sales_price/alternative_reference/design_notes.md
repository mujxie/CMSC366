# A second valid solution
The first reference snapshots the unit price in each sale. This solution stores immutable price versions and makes each sale reference the version selected when it happened. Neither design is intrinsically the only correct answer. The contract is preserved in both.
