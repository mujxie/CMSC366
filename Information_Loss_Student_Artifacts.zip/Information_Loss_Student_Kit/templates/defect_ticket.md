# Database-design defect review
Artifact ID:
Brief / requirement version:
Reviewer and date:
Raw output hash:

## Requirement and expected answer
State the business obligation and independently checked answer.

## Reproduction
Exact command:
History IDs:
Observed answer:
Relevant stored tables/columns:

## Classification
Choose a code from DECISION_CODES.txt. A report mismatch alone is not proof of information loss.

## Paired-history evidence
H1/H2 event differences:
Required answers differ because:
Declared stored states are equal / unequal / unavailable:
Extra audit, version, JSON, or other encoded information checked:
Event-mapping fidelity reviewed:
Could changing only the query recover the answer?:

## Decision and uncertainty
Confirmed for evaluated representation and update policy / query-only / ambiguous / test defect:
Reasoning:
Second reviewer:
Disagreement and resolution:

## Correction
Candidate repair and additional test:
Is this a fresh rebuild rather than a migration?:
Does the repair preserve previously correct cases?:
