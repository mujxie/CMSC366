CREATE TABLE products (
 product_id INTEGER PRIMARY KEY, product_name TEXT NOT NULL,
 current_price_cents INTEGER NOT NULL CHECK(current_price_cents >= 0));
CREATE TABLE customers (customer_id INTEGER PRIMARY KEY, customer_name TEXT NOT NULL);
CREATE TABLE sales (
 sale_id INTEGER PRIMARY KEY, customer_id INTEGER NOT NULL REFERENCES customers(customer_id),
 product_id INTEGER NOT NULL REFERENCES products(product_id), sale_day TEXT NOT NULL,
 quantity INTEGER NOT NULL CHECK(quantity > 0), unit_price_cents INTEGER NOT NULL CHECK(unit_price_cents >= 0));
CREATE TABLE returns (
 return_id INTEGER PRIMARY KEY, sale_id INTEGER NOT NULL REFERENCES sales(sale_id),
 return_day TEXT NOT NULL, refund_cents INTEGER NOT NULL CHECK(refund_cents > 0));
