# Sources and scope

Checked October 3, 2026. These are sources for background and design choices, not evidence that this proposed study is novel or has produced AI-model results.

[S1] O*NET. Business Intelligence Analysts — Hot Technologies (2025 U.S. postings). SQL 35%, Power BI 20%, Excel 17%; occupation-wide, not entry-level probabilities.
https://www.onetonline.org/link/hot_tech/15-2051.01

[S3] O*NET. Database Architects — tasks and knowledge.
https://www.onetonline.org/link/summary/15-1243.00

[S2] O*NET. Business Intelligence Analysts — tasks and knowledge.
https://www.onetonline.org/link/summary/15-2051.01

[S4] Python Software Foundation. sqlite3 — DB-API 2.0 interface for SQLite databases.
https://docs.python.org/3/library/sqlite3.html

[S5] SQLite. Foreign Key Support; PRAGMA documentation.
https://www.sqlite.org/foreignkeys.html
https://www.sqlite.org/pragma.html

[S6] SQLite. Datatypes in SQLite. SQLite typing is not identical to PostgreSQL or SQL Server; validation must consider that difference.
https://www.sqlite.org/datatype3.html

[S7] Qin Wang et al. Text2Schema (2025), arXiv:2503.23886. Inspect the current record for exact author list/version before bibliographic submission. Related schema-generation and refinement work; do not claim AI schema generation is new.
https://arxiv.org/abs/2503.23886
https://arxiv.org/html/2503.23886v2

[S8] Phil McMinn, Chris J. Wright, Cody Kinneer, Colton J. McCurdy, Michael Camara, and Gregory M. Kapfhammer. SchemaAnalyst: Search-Based Test Data Generation for Relational Database Schemas. ICSME 2016, 586–590. Related integrity-constraint testing.
https://philmcminn.com/publications/mcminn2016.pdf
https://philmcminn.com/publications/search-based-test-generation

[S9] Microsoft Learn. Understand star schema and the importance for Power BI. Row grain, dimensions, relationships, and historical-version concepts are established practice, not new inventions of this project.
https://learn.microsoft.com/en-us/power-bi/guidance/star-schema/

[S10] SIGCSE TS 2027. ACM Student Research Competition instructions. Four review headings used as a preparation guide. Recheck dates and format for the actual future target cycle.
https://2027.sigcse-ts.acm.org/track/sigcse-ts-2027-acm-student-research-competition

[S11] SIGCSE TS 2027. AI policy. Preserve appropriate research-code/design assistance disclosure; current target-cycle policy controls.
https://2027.sigcse-ts.acm.org/info/policies-ai
