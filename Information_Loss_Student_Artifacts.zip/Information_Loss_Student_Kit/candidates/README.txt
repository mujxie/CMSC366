Put collected AI candidate folders here. Do not copy teaching fixtures into the empirical sample. Use tools/study.py init-candidate to create a blank folder.
