CREATE TABLE plans (plan_id INTEGER PRIMARY KEY, current_fee_cents INTEGER NOT NULL CHECK (current_fee_cents >= 0));
CREATE TABLE enrollments (enrollment_id INTEGER PRIMARY KEY, plan_id INTEGER NOT NULL REFERENCES plans(plan_id), agreed_fee_cents INTEGER NOT NULL);
