# First design example

## Required information
For every recorded sale, preserve the quantity and price charged when the sale occurred. A later product-price change must not rewrite the historical sales amount.

## Deliberately flawed teaching design
Products(product_id, current_price_cents)
Sale_items(sale_id, product_id, quantity)

Relationship: one product has many sale items. Joining each sale to the current product price produces the wrong historical charge after a price change. Two distinct original prices can lead to the same final stored state.

## Snapshot-price reference
Products(product_id, current_price_cents)
Sale_items(sale_id, product_id, quantity, unit_price_cents)

At a sale, copy the price actually charged into the sale row. The event contract in this small benchmark fixes that price to the current product price at the sale event; real discounts would require a richer contract.

## Alternative correct versioned design
Products(product_id)
Price_versions(product_id, version_no, price_cents)
Sale_items(sale_id, product_id, version_no, quantity)

Keep immutable price versions and link the sale to its version. This is a different valid design, not a failure to match the snapshot reference. The adapter assumes single-user execution, as declared by the kit.

These are supplied teaching designs. Students should draw the ER relationships themselves and explain every foreign key and event mapping. Do not submit them as independently collected AI outputs.
