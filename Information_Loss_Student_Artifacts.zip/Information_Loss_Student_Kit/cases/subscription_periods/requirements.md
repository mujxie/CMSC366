# Preserving cancellations and re-enrollments

Brief ID: `subscription_periods`

A subscriber may join, cancel, and later join again. Each enrollment period has a supplied unique period ID. The service must retain all active and completed periods so it can identify gaps in membership. Report every period ID, its start date, and its end date. A NULL end date means active. Intervals are [start,end), and valid events do not create overlapping periods for one subscriber.

## Deliverable
Design a relational schema and SQL operations for the event interface in `contract.json`. Implement the report using only stored database information. Different schema structures and names are allowed. SQL should target SQLite. Supply `schema.sql`, `adapter.json`, and a short design explanation.

## Fixed boundaries
Synthetic single-user events in chronological order. No overlapping episodes per entity, backdated corrections, deletion requests, or concurrency. Reports may read only the database, not the history file.

Money, where relevant, is stored as integer cents, not binary floating-point dollars. All event identifiers are supplied by the caller. Do not assume that current values equal historical values. Do not copy the reference solution or inspect held-out histories before freezing a candidate.
