# Preserving the address used for an order

Brief ID: `shipping_address`

A shop maintains a customer's current address. At order placement the current address becomes that order's shipping address. Customers may later change their address, but an already placed order must continue to report its original shipping address. Report every order ID and the address used when it was placed. Addresses are nonempty text strings. Changing an old order's destination is outside the scope.

## Deliverable
Design a relational schema and SQL operations for the event interface in `contract.json`. Implement the report using only stored database information. Different schema structures and names are allowed. SQL should target SQLite. Supply `schema.sql`, `adapter.json`, and a short design explanation.

## Fixed boundaries
Synthetic, single-user, no concurrency, no taxes, no discounts, no backdated correction. IDs are supplied and stable. Do not use an external log or the test input to answer reports.

Money, where relevant, is stored as integer cents, not binary floating-point dollars. All event identifiers are supplied by the caller. Do not assume that current values equal historical values. Do not copy the reference solution or inspect held-out histories before freezing a candidate.
