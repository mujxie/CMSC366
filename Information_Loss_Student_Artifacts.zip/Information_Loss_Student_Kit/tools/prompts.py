#!/usr/bin/env python3
"""Build prompts without opening held-out fixtures. No network or model calls."""
import argparse, json, hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
FORMAT='''Return one JSON object with keys "schema_sql", "adapter", and "design_notes".
"schema_sql" is executable SQLite DDL. "adapter" has "operations" (each exact
operation name maps to a list of parameterized SQL statements) and "query" (a
SELECT returning the required report columns in order). Use :parameter names
from the contract. Queries must read only persisted database tables, not input
histories. Do not add files, hidden state, hard-coded answers, or expected data.
Do not add sample rows to DDL. Avoid PRAGMA, ATTACH, virtual tables, randomness,
and wall-clock values. Use event IDs and dates supplied by the contract. Record
all required information, but choose your own schema and table/column names.
No model-specific API, tools, or internet access is needed for this task.
'''

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--case',required=True)
    p.add_argument('--stage',choices=['baseline','self_review','example_review'],required=True)
    p.add_argument('--candidate',type=Path)
    p.add_argument('--out',type=Path,required=True)
    a=p.parse_args()
    b=ROOT/'cases'/a.case
    req=(b/'requirements.md').read_text(encoding='utf-8')
    # requirements file has classroom logistics; model gets only business scope.
    c=json.loads((b/'contract.json').read_text(encoding='utf-8'))
    text='Design task\n\n'+c['scope']+'\n\nFixed scope\n'+c['allowed_scope']+'\n\nEvent and report contract\n'+json.dumps(c,indent=2)+'\n\n'+FORMAT
    if a.stage!='baseline':
        if not a.candidate:p.error('--candidate is required for either review stage')
        original={'schema_sql':(a.candidate/'schema.sql').read_text(encoding='utf-8'),'adapter':json.loads((a.candidate/'adapter.json').read_text(encoding='utf-8'))}
        text+='\nOriginal design to review (same original in both branches)\n'+json.dumps(original,indent=2)
        text+='\nCheck the entire original design against all requirements. Revise if necessary. Return a complete replacement JSON object, not a patch. One revision round only.\n'
        if a.stage=='example_review':
            h=json.loads((b/'public.json').read_text(encoding='utf-8'))['histories']
            # Fixed public diagnostic pair, never selected using a held-out result.
            pair=[{'history_id':x['history_id'],'events':x['events'],'required_report':x['expected']} for x in h if x.get('pair_id')=='public_pair']
            text+='\nAdditional review evidence\nThe following two valid business histories must produce the listed reports. Check whether the original design preserves enough information to distinguish them. These are diagnostic examples, not a prescribed schema or a claim that your original design fails.\n'+json.dumps(pair,indent=2)+'\n'
    if a.out.exists():raise SystemExit('Refusing to overwrite an existing prompt.')
    a.out.parent.mkdir(parents=True,exist_ok=True)
    a.out.write_text(text,encoding='utf-8')
    print('Saved',a.out,'SHA256',hashlib.sha256(text.encode()).hexdigest())
if __name__=='__main__':main()
