CREATE TABLE equipment (equipment_id INTEGER PRIMARY KEY, current_rate_cents INTEGER NOT NULL CHECK (current_rate_cents >= 0));
CREATE TABLE agreements (rental_id INTEGER PRIMARY KEY, equipment_id INTEGER NOT NULL REFERENCES equipment(equipment_id), agreed_rate_cents INTEGER NOT NULL);
