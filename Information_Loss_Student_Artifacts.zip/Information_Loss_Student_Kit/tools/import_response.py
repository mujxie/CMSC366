#!/usr/bin/env python3
"""Preserve a real model response, then extract the agreed JSON artifact format.
Invalid JSON is preserved and logged, not silently repaired or called a success.
"""
import argparse, json, re, hashlib
from datetime import datetime, timezone
from pathlib import Path

def main():
    p=argparse.ArgumentParser(description=__doc__)
    for key in ['response','prompt','out']:
        p.add_argument('--'+key,type=Path,required=True)
    for key in ['case','id','parent','model','provider','model-alias']:
        p.add_argument('--'+key,required=True)
    p.add_argument('--replicate',type=int,required=True)
    p.add_argument('--stage',choices=['baseline','self_review','example_review'],required=True)
    p.add_argument('--settings',default='Not exposed by interface; record manually before analysis')
    p.add_argument('--generated-utc',required=True,help='Actual response timestamp, not the import time')
    a=p.parse_args()
    a.out.mkdir(parents=True,exist_ok=False)
    raw=a.response.read_text(encoding='utf-8');prompt=a.prompt.read_text(encoding='utf-8')
    (a.out/'raw_response.txt').write_text(raw,encoding='utf-8')
    (a.out/'prompt.txt').write_text(prompt,encoding='utf-8')
    m={'artifact_id':a.id,'parent_id':a.parent,'brief_id':a.case,'origin':'llm_collected','stage':a.stage,'model':a.model,'model_alias':a.model_alias,'provider':a.provider,'replicate':a.replicate,'generated_utc':a.generated_utc,'imported_utc':datetime.now(timezone.utc).isoformat(),'settings':a.settings,'raw_output_file':'raw_response.txt','raw_sha256':hashlib.sha256(raw.encode()).hexdigest(),'prompt_sha256':hashlib.sha256(prompt.encode()).hexdigest(),'adapter_reviewed':False,'adapter_reviewer':'','student_owner':'FILL_NAME','extraction_status':'pending'}
    cleaned=raw.strip()
    if cleaned.startswith('```'):
        match=re.fullmatch(r'```(?:json)?\s*\n(.*)\n```',cleaned,re.S)
        if match:cleaned=match.group(1)
    try:
        obj=json.loads(cleaned)
        if not isinstance(obj['schema_sql'],str) or not isinstance(obj['adapter'],dict):raise ValueError('Wrong schema_sql or adapter type')
        (a.out/'schema.sql').write_text(obj['schema_sql'],encoding='utf-8')
        (a.out/'adapter.json').write_text(json.dumps(obj['adapter'],indent=2)+'\n',encoding='utf-8')
        notes=obj.get('design_notes','No design explanation supplied.')
        (a.out/'design_notes.md').write_text(notes if isinstance(notes,str) else json.dumps(notes,indent=2),encoding='utf-8')
        m['extraction_status']='parsed_not_yet_reviewed'
    except (ValueError,KeyError,TypeError) as e:
        m['extraction_status']='format_failure';m['extraction_error']=str(e)
    (a.out/'manifest.json').write_text(json.dumps(m,indent=2)+'\n',encoding='utf-8')
    print(m['extraction_status'],a.out)
    if m['extraction_status']=='format_failure':raise SystemExit(2)
if __name__=='__main__':main()
