# Preserving repeated equipment rentals

Brief ID: `rental_visits`

An equipment desk records each rental of an asset as a separate episode. The same asset can be rented, returned, and rented again. Each rental receives a supplied unique rental ID. Record checkout and return dates, and preserve completed rentals after the asset is rented again. Report every rental ID with checkout and return dates. A NULL return means still rented. The caller supplies valid nonoverlapping episodes for an asset.

## Deliverable
Design a relational schema and SQL operations for the event interface in `contract.json`. Implement the report using only stored database information. Different schema structures and names are allowed. SQL should target SQLite. Supply `schema.sql`, `adapter.json`, and a short design explanation.

## Fixed boundaries
Synthetic single-user events in chronological order. No overlapping episodes per entity, backdated corrections, deletion requests, or concurrency. Reports may read only the database, not the history file.

Money, where relevant, is stored as integer cents, not binary floating-point dollars. All event identifiers are supplied by the caller. Do not assume that current values equal historical values. Do not copy the reference solution or inspect held-out histories before freezing a candidate.
