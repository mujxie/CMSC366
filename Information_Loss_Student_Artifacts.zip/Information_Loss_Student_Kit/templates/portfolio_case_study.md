# Portfolio case study

Replace every instruction with your own evidence. Do not claim skills or results you cannot demonstrate.

## Business question
What must the business know after prices, addresses, or relationships change? State the exact requirement and why it matters.

## My contribution
List the SQL, requirement analysis, test cases, repair, and documentation you personally authored. Identify supplied code, teammate work, AI assistance, and supervisor help.

## Design and data
Include your ER diagram and explain the meaning of one row in each table. Give primary/foreign keys and show how the historical value is retained. Use synthetic data only.

## A failure I investigated
Give the smallest useful event sequence, expected answer, actual answer, and relevant query. Distinguish a query mistake from information lost by the design and its update behavior.

## Repair and checks
Explain what changed and why. Show an additional case not used while developing the repair and one previously correct case that still passes. State whether this is a fresh-database redesign; do not imply it recovers information already lost in a live database.

## Working demonstration
Give exact commands and paths. Explain the three generated reports and trace a displayed number to source rows and SQL. Record software versions.

## Limitations and next step
Name an unsupported case. Do not present a small teaching database as a production system.

## Interview explanation
In 90 seconds: requirement -> design -> defect -> evidence -> repair -> new test -> business consequence.

## Evidence links
Repository commit, SQL scripts, raw inputs, test outputs, logs, and screenshots (optional). Never include passwords or private customer data.
