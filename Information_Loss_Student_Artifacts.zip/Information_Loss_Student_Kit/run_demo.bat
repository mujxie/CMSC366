@echo off
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 tools\study.py demo --out outputs\my_first_demo
) else (
  python tools\study.py demo --out outputs\my_first_demo
)
pause
