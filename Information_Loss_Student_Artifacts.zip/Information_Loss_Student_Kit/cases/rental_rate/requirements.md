# Preserving an agreed daily rental rate

Brief ID: `rental_rate`

A rental business publishes a current daily rate for each equipment type. Each new agreement records the daily rate agreed at its creation; this rate stays fixed even if the advertised rate later changes. Report each rental agreement ID and its agreed daily rate in cents. Billing duration, overdue penalties, discounts, and retroactive corrections are outside scope.

## Deliverable
Design a relational schema and SQL operations for the event interface in `contract.json`. Implement the report using only stored database information. Different schema structures and names are allowed. SQL should target SQLite. Supply `schema.sql`, `adapter.json`, and a short design explanation.

## Fixed boundaries
Synthetic, single-user, no concurrency, no taxes, no discounts, no backdated correction. IDs are supplied and stable. Do not use an external log or the test input to answer reports.

Money, where relevant, is stored as integer cents, not binary floating-point dollars. All event identifiers are supplied by the caller. Do not assume that current values equal historical values. Do not copy the reference solution or inspect held-out histories before freezing a candidate.
