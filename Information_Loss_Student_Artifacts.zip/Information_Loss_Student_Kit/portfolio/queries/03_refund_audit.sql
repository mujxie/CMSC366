-- An empty result means no sale exceeds its amount charged in this sample.
SELECT s.sale_id, s.quantity*s.unit_price_cents AS charged_cents,
       SUM(r.refund_cents) AS refunded_cents
FROM sales s JOIN returns r ON s.sale_id=r.sale_id
GROUP BY s.sale_id,s.quantity,s.unit_price_cents
HAVING SUM(r.refund_cents) > s.quantity*s.unit_price_cents;
