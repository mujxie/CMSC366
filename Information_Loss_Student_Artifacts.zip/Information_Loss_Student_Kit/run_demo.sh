#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
python3 tools/study.py demo --out outputs/my_first_demo
