# Preserving the fee agreed at enrollment

Brief ID: `subscription_fee`

A subscription service has plans with current monthly fees. For this business rule, a new enrollment locks in the fee at enrollment time. Changes to the advertised plan fee apply only to future enrollments. Report each enrollment ID and the monthly fee agreed at enrollment. Plan switching, proration, taxes, and retroactive corrections are outside scope. Do not assume existing customers are automatically repriced.

## Deliverable
Design a relational schema and SQL operations for the event interface in `contract.json`. Implement the report using only stored database information. Different schema structures and names are allowed. SQL should target SQLite. Supply `schema.sql`, `adapter.json`, and a short design explanation.

## Fixed boundaries
Synthetic, single-user, no concurrency, no taxes, no discounts, no backdated correction. IDs are supplied and stable. Do not use an external log or the test input to answer reports.

Money, where relevant, is stored as integer cents, not binary floating-point dollars. All event identifiers are supplied by the caller. Do not assume that current values equal historical values. Do not copy the reference solution or inspect held-out histories before freezing a candidate.
