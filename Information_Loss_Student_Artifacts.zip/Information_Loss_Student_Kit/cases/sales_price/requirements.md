# Preserving the amount charged for a sale

Brief ID: `sales_price`

A shop sells products. Each product has a current price, which may change. When a sale occurs, record its supplied sale ID, product ID, and positive quantity. The price charged is the product price in force at that moment. Later price changes must not change the recorded amount charged for an earlier sale. Report each sale ID and its original total in cents. There are no discounts, tax, shipping charges, refunds, or retroactive corrections in this brief.

## Deliverable
Design a relational schema and SQL operations for the event interface in `contract.json`. Implement the report using only stored database information. Different schema structures and names are allowed. SQL should target SQLite. Supply `schema.sql`, `adapter.json`, and a short design explanation.

## Fixed boundaries
Synthetic, single-user, no concurrency, no taxes, no discounts, no backdated correction. IDs are supplied and stable. Do not use an external log or the test input to answer reports.

Money, where relevant, is stored as integer cents, not binary floating-point dollars. All event identifiers are supplied by the caller. Do not assume that current values equal historical values. Do not copy the reference solution or inspect held-out histories before freezing a candidate.
